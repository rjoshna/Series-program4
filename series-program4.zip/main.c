/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <math.h>

int main()
{
    int n;
    printf("enter the value of n:");
    scanf("%d",&n);
    if(n%2==1){
        int term = pow(2,n/2);
        printf("the %dth term ids :%d\n",n,term);
    }else{
        int term = pow(3,(n/2)-1);
        printf("the %dth term ids: %d\n",n,term);
    }

    return 0;
}